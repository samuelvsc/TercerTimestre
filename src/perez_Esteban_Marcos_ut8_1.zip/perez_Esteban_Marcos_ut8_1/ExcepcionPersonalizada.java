package perez_Esteban_Marcos_ut8_1;

public class ExcepcionPersonalizada extends Exception{
    public ExcepcionPersonalizada(){
        super();
    }
    public ExcepcionPersonalizada(String msj){
        super(msj);
    }
}
